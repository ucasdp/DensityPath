
rm(list=ls())
# Install and library the following R packages
install.packages("TDA")
install.packages("gdistance")
install.packages("raster")
install.packages("vegan")
install.packages("shape")
source("https://bioconductor.org/biocLite.R")
biocLite('destiny')

library("TDA")
library("gdistance")
library("raster")
library("vegan")
library("shape")
library("destiny")
library('R.matlab')



#Each row of data represents one cell and each column represents one gene
after_pca <- function(data){
  data_guiyi <- (data-min(data))/(max(data)-min(data))
  data_cov <- cov(data_guiyi)
  data_eigen <- eigen(data_cov)
  lambdanum <- min(which(abs(diff(data_eigen$values,2))<1e-3))
  data_pca <- data_guiyi%*%data_eigen$vectors[,1:lambdanum]
  return(data_pca)
}
#perform EE in matlab####

#Obtain the result of DensityPaht####
densitypathimage<-function(XX,pdfname){
  
  XX <- (XX-min(XX))/(max(XX)-min(XX))
  k <- round(nrow(XX)/100)
  n <- dim(XX)[1]
  d <- dim(XX)[2]
  distMat <- XX
  adjMat <- diag(n)
  knnInfo <- FNN::get.knn(XX, k = k, algorithm = "kd_tree")
  for (i in seq_len(n)) {
    adjMat[i, knnInfo[["nn.index"]][i, ]] <- 1
  }
  # h <- Hns(XX)
  h <- Hpi(XX)
  # h <- Hlscv(XX)
  # hat.f <- ks::kde(XX, H = h, eval.points = XX, binned = FALSE)
  hat.f <- ks::kde(XX, H = h, eval.points = XX)
  hat.f <- hat.f$estimate
  ord.hat.f <- order(hat.f)
  G <- igraph::graph.adjacency(adjMat, mode = "undirected")
  Lambda <- hat.f[ord.hat.f]
  Nlambda <- min(n, 150)
  Lambda <- seq(min(Lambda), max(Lambda), length = Nlambda)
  exclude <- numeric()
  CLUSTERS <- list()
  for (j in seq_len(Nlambda)) {
    OldExcluded <- exclude
    lambda <- Lambda[j]
    present <- which(hat.f >= lambda)
    exclude <- setdiff(seq_len(n), present)
    NewExcluded <- setdiff(exclude, OldExcluded)
    G[NewExcluded, present] <- FALSE
    clust <- igraph::clusters(G)
    CLUSTERS[[j]] <- list(no = clust[["no"]], mem = clust[["membership"]], 
                          present = present, exclude = exclude)
  }
  id <- 0
  components <- list()
  generation <- numeric()
  for (j in seq_len(Nlambda)) {
    presentMembership <- unique(CLUSTERS[[j]][["mem"]][CLUSTERS[[j]][["present"]]])
    for (i in presentMembership) {
      id <- id + 1
      components[[id]] <- which(CLUSTERS[[j]][["mem"]] == i)
      generation[id] <- j
    }
  }
  father <- numeric()
  startF <- which(generation == 2)[1]
  for (i in startF:length(components)) {
    for (j in which(generation == (generation[i] - 1))) {
      if (setequal(intersect(components[[i]], components[[j]]), 
                   components[[i]])) {
        father[i] <- j
        break
      }
    }
  }
  father[is.na(father)] <- 0
  bb <- 0
  branch <- numeric()
  base <- numeric()
  top <- numeric()
  bottom <- numeric()
  compBranch <- list()
  silo <- list()
  rank <- numeric()
  parent <- numeric()
  children <- list()
  if (sum(generation == 1) > 1) {
    bb <- bb + 1
    silo[[bb]] <- c(0, 1)
    base[bb] <- 0.5
    compBranch[[bb]] <- seq_len(n)
    rank[bb] <- 1
    parent[bb] <- 0
    top[bb] <- 0
    bottom[bb] <- 0
  }
  for (i in seq(along = father)) {
    if (sum(generation == 1) > 1 & generation[i] == 1) {
      Bros <- which(generation == generation[i])
      bb <- bb + 1
      branch[i] <- bb
      rank[bb] <- sum(generation[seq_len(i)] == generation[i] & 
                        father[seq_len(i)] == father[i])
      silo[[bb]] <- TDA:::siloF(c(0, 1), length(Bros), rank[bb])
      base[bb] <- sum(silo[[bb]])/2
      top[bb] <- min(hat.f[components[[i]]])
      compBranch[[bb]] <- components[[i]]
      parent[bb] <- 1
      bottom[bb] <- 0
      if (length(children) < parent[bb]) {
        children[[parent[bb]]] <- bb
      }
      else {
        children[[parent[bb]]] <- c(children[[parent[bb]]], 
                                    bb)
      }
    }
    else if (sum(generation == 1) == 1 & generation[i] == 
             1) {
      bb <- bb + 1
      branch[i] <- bb
      silo[[bb]] <- c(0, 1)
      base[bb] <- 0.5
      top[bb] <- min(hat.f[components[[i]]])
      compBranch[[bb]] <- components[[i]]
      parent[bb] <- 0
      bottom[bb] <- 0
    }
    else {
      Bros <- which(generation == generation[i] & father == 
                      father[i])
      if (length(Bros) > 1) {
        bb <- bb + 1
        branch[i] <- bb
        parent[bb] <- branch[father[i]]
        rank[bb] <- sum(generation[seq_len(i)] == generation[i] & 
                          father[seq_len(i)] == father[i])
        silo[[bb]] <- TDA:::siloF(silo[[parent[bb]]], length(Bros), 
                                  rank[bb])
        base[bb] <- sum(silo[[bb]])/2
        top[bb] <- min(hat.f[components[[i]]])
        bottom[bb] <- top[parent[bb]]
        compBranch[[bb]] <- components[[i]]
        if (length(children) < parent[bb]) {
          children[[parent[bb]]] <- bb
        }
        else {
          children[[parent[bb]]] <- c(children[[parent[bb]]], 
                                      bb)
        }
      }
      if (length(Bros) == 1) {
        for (j in which(generation == (generation[i] - 
                                       1))) {
          if (setequal(intersect(components[[i]], components[[j]]), 
                       components[[i]])) 
            belongTo <- branch[j]
        }
        top[belongTo] <- min(hat.f[components[[i]]])
        branch[i] <- belongTo
      }
    }
  }
  
  
  out <- list(density = hat.f, DataPoints = compBranch, 
              n = n, id = seq_len(bb), children = children, parent = parent, 
              silo = silo, Xbase = base, lambdaBottom = bottom, 
              lambdaTop = top)
  
  TreeKDE <- out
  densityKDE<-TreeKDE$density
  idKDE<-setdiff(TreeKDE$id,TreeKDE$parent)
  numKDEleaves<-length(idKDE)
  l<-1
  KDEdensitypeaks<-matrix(1,numKDEleaves,2)
  for (i in idKDE){
    clusterkde<-TreeKDE$DataPoints[[i]]
    KDEdensitypeaks[l,]<-XX[clusterkde[which.max(densityKDE[clusterkde])],]
    l<-l+1
  }
  xmin <-min(XX)
  xmax<-max(XX)
  ymin<-min(XX)
  ymax<-max(XX)
  numcell<-nrow(XX)
  if (numcell<=10000)
  {
    numx<-101
    numy<-101
  }
  if(numcell>10000)
  {
    numx<-501
    numy<-501
  }
  Xlim <- c(xmin,xmax);  Ylim <- c(ymin, ymax);  
  by <- (xmax-xmin)/(numx-1)
  Xseq <- seq(Xlim[1], Xlim[2], by = by)
  Yseq <- seq(Ylim[2],Ylim[1], by = -by)
  Grid <- expand.grid(Xseq, Yseq)
  # calculate the density on the grid,and form a density surface
  # h <- Hns(XX)
  # h <- Hpi(XX)
  # h <- Hlscv(XX)
  KDE <- ks::kde(XX, H = h, eval.points = Grid)$estimate
  # KDE <- ks::kde(XX, H = h, eval.points = Grid, binned = FALSE)$estimate
  KDE[which(KDE<0)] <- 0
  r <- raster(nrows=numy, ncols=numx, xmn=xmin, xmx=xmax, ymn=ymin, ymx=ymax,crs="+proj=utm +units=m")
  r[] <- KDE
  T <- transition(r, function(x) mean(x), 8)
  T <- geoCorrection(T)
  C <-KDEdensitypeaks
  D <-KDEdensitypeaks
  # use the costDistance function in the gdistance package to calculate the geodesic distance between any two density peaks of 
  # the mesh surface
  dis<- costDistance(T, C, D)
  # calculate the minimun spanning tree by calling the spantree function in the vegan package using the geodesic distance matrix.
  spanningtree <- spantree(dis)
  # Output of the graph
  pdf(paste('Densitypath ',pdfname,'.pdf',sep = ''))
  par(mfrow = c(2,2))
  par(mai = c(0.7,0.4,0.4,0.4),oma=c(0.7,0.7,0.7,0.7))
  # 2-dimensional projection
  par(mgp=c(1,1,0))
  plot(XX, pch = 19, cex = 0.6, main =paste('2D projection ',sep = ''),xaxt="n",yaxt="n",
       xlab = 'EE1', ylab = 'EE2', bty = 'l', sub = '(a)', cex.sub = 1.3, font.sub = 2)
  # 3-dimensional density surface
  Xseq <- seq(Xlim[1], Xlim[2], by = by)
  Yseq <- seq(Ylim[1],Ylim[2], by = by)
  Grid <- expand.grid(Xseq, Yseq)
  KDE <- ks::kde(XX, H = h, eval.points = Grid, binned = F)$estimate
  zh<- matrix(KDE,ncol=length(Yseq),nrow=length(Xseq))
  op <- par(bg = "white")
  res<-persp(Xseq, Yseq, zh, theta = 345, phi = 30,
             expand = 0.5, col = "white",d =1,
             r=90,
             ltheta = 90,
             shade = 0, 
             ticktype = "detailed",
             #xlab = "X", ylab = "Y", zlab = "Sinc( r )" ,
             box = TRUE,
             border=NA,main='Density landscape',
             axes=F,
             sub = '(b)',cex.sub = 1.3, font.sub = 2
  )
  # discrete density clusters
  par(mgp=c(1,1,0))
  plot(1:5,1:5,xlim=c(min(XX[,1]),max(XX[,1])),ylim=c(min(XX[,2]),max(XX[,2])),type = "n",main = "Density clusters",xlab="EEC1",ylab="EEC2",
       xaxt = 'n', yaxt = 'n', bty = 'l', sub = '(c)',cex.sub = 1.3, font.sub = 2)
  col <- intpalette(c('red','black','green','blue','pink','yellow','grey','orange','purple','cyan'),length(idKDE))
  c <- 1
  for (i in idKDE){
    points(matrix(XX[TreeKDE[["DataPoints"]][[i]], ], ncol = 2), col = col[c],pch = 19, cex = 1.5)
    c<-c+1
  }
  # density path
  p<-matrix(1,2,2)
  par(mgp=c(1,1,0))
  plot(r,xlim=c(min(XX[,1]),max(XX[,1])),ylim=c(min(XX[,2]),max(XX[,2])),main="Density path",xlab="EE1",ylab="EE2",
       xaxt = 'n', yaxt = 'n', sub = '(d)',cex.sub = 1.3, font.sub = 2)
  KDEidspantree<-spanningtree$kid
  numKDEedge<-numKDEleaves-1
  KDEspantree<-matrix(1,numKDEedge,2)
  KDEspantree[,1]<-as.matrix(2:numKDEleaves,numKDEleaves,1)
  KDEspantree[,2]<-t(KDEidspantree)
  for (i in 1:numKDEedge){
    p1<-KDEspantree[i,1]
    p2<-KDEspantree[i,2]
    p[1,]<-KDEdensitypeaks[p1,]
    p[2,]<-KDEdensitypeaks[p2,]
    p1top2 <- shortestPath(T, p[1,], p[2,], output="SpatialLines")
    lines(p1top2, col="black", lwd=1)
  }
  for (i in 1:numKDEleaves){
    points(KDEdensitypeaks[i,1],KDEdensitypeaks[i,2],pch = 19, cex = 1,col="black")
  }
  
  dev.off()
  # return(1)
}



#Calculate the pseudotime 
dens_bran_pseu <- function(XX, originid){
  #####If originid, the number of start point, is missing, pseudotime will not be calculated, but the 
  #branch assignment of each cell will still be calculated. The originid doesn't influence the result of 
  #branch assignment therefore we set the first cell as the start point to calculate it.
  XX <- (XX-min(XX))/(max(XX)-min(XX))
  k <- round(nrow(XX)/100)
  #clusterTree#####
  n <- dim(XX)[1]
  d <- dim(XX)[2]
  distMat <- XX
  adjMat <- diag(n)
  knnInfo <- FNN::get.knn(XX, k = k, algorithm = "kd_tree")
  for (i in seq_len(n)) {
    adjMat[i, knnInfo[["nn.index"]][i, ]] <- 1
  }
  h <- Hpi(XX)
  hat.f <- ks::kde(XX,H = h, eval.points = XX)
  hat.f <- hat.f$estimate
  ord.hat.f <- order(hat.f)
  G <- igraph::graph.adjacency(adjMat, mode = "undirected")
  Lambda <- hat.f[ord.hat.f]
  Nlambda <- min(n, 150)
  Lambda <- seq(min(Lambda), max(Lambda), length = Nlambda)
  exclude <- numeric()
  CLUSTERS <- list()
  for (j in seq_len(Nlambda)) {
    OldExcluded <- exclude
    lambda <- Lambda[j]
    present <- which(hat.f >= lambda)
    exclude <- setdiff(seq_len(n), present)
    NewExcluded <- setdiff(exclude, OldExcluded)
    G[NewExcluded, present] <- FALSE
    clust <- igraph::clusters(G)
    CLUSTERS[[j]] <- list(no = clust[["no"]], mem = clust[["membership"]], 
                          present = present, exclude = exclude)
  }
  id <- 0
  components <- list()
  generation <- numeric()
  for (j in seq_len(Nlambda)) {
    presentMembership <- unique(CLUSTERS[[j]][["mem"]][CLUSTERS[[j]][["present"]]])
    for (i in presentMembership) {
      id <- id + 1
      components[[id]] <- which(CLUSTERS[[j]][["mem"]] == i)
      generation[id] <- j
    }
  }
  father <- numeric()
  startF <- which(generation == 2)[1]
  for (i in startF:length(components)) {
    for (j in which(generation == (generation[i] - 1))) {
      if (setequal(intersect(components[[i]], components[[j]]), 
                   components[[i]])) {
        father[i] <- j
        break
      }
    }
  }
  father[is.na(father)] <- 0
  bb <- 0
  branch <- numeric()
  base <- numeric()
  top <- numeric()
  bottom <- numeric()
  compBranch <- list()
  silo <- list()
  rank <- numeric()
  parent <- numeric()
  children <- list()
  if (sum(generation == 1) > 1) {
    bb <- bb + 1
    silo[[bb]] <- c(0, 1)
    base[bb] <- 0.5
    compBranch[[bb]] <- seq_len(n)
    rank[bb] <- 1
    parent[bb] <- 0
    top[bb] <- 0
    bottom[bb] <- 0
  }
  for (i in seq(along = father)) {
    if (sum(generation == 1) > 1 & generation[i] == 1) {
      Bros <- which(generation == generation[i])
      bb <- bb + 1
      branch[i] <- bb
      rank[bb] <- sum(generation[seq_len(i)] == generation[i] & 
                        father[seq_len(i)] == father[i])
      silo[[bb]] <- TDA:::siloF(c(0, 1), length(Bros), rank[bb])
      base[bb] <- sum(silo[[bb]])/2
      top[bb] <- min(hat.f[components[[i]]])
      compBranch[[bb]] <- components[[i]]
      parent[bb] <- 1
      bottom[bb] <- 0
      if (length(children) < parent[bb]) {
        children[[parent[bb]]] <- bb
      }
      else {
        children[[parent[bb]]] <- c(children[[parent[bb]]], 
                                    bb)
      }
    }
    else if (sum(generation == 1) == 1 & generation[i] == 
             1) {
      bb <- bb + 1
      branch[i] <- bb
      silo[[bb]] <- c(0, 1)
      base[bb] <- 0.5
      top[bb] <- min(hat.f[components[[i]]])
      compBranch[[bb]] <- components[[i]]
      parent[bb] <- 0
      bottom[bb] <- 0
    }
    else {
      Bros <- which(generation == generation[i] & father == 
                      father[i])
      if (length(Bros) > 1) {
        bb <- bb + 1
        branch[i] <- bb
        parent[bb] <- branch[father[i]]
        rank[bb] <- sum(generation[seq_len(i)] == generation[i] & 
                          father[seq_len(i)] == father[i])
        silo[[bb]] <- TDA:::siloF(silo[[parent[bb]]], length(Bros), 
                                  rank[bb])
        base[bb] <- sum(silo[[bb]])/2
        top[bb] <- min(hat.f[components[[i]]])
        bottom[bb] <- top[parent[bb]]
        compBranch[[bb]] <- components[[i]]
        if (length(children) < parent[bb]) {
          children[[parent[bb]]] <- bb
        }
        else {
          children[[parent[bb]]] <- c(children[[parent[bb]]], 
                                      bb)
        }
      }
      if (length(Bros) == 1) {
        for (j in which(generation == (generation[i] - 
                                       1))) {
          if (setequal(intersect(components[[i]], components[[j]]), 
                       components[[i]])) 
            belongTo <- branch[j]
        }
        top[belongTo] <- min(hat.f[components[[i]]])
        branch[i] <- belongTo
      }
    }
  }
  out <- list(density = hat.f, DataPoints = compBranch, 
              n = n, id = seq_len(bb), children = children, parent = parent, 
              silo = silo, Xbase = base, lambdaBottom = bottom, 
              lambdaTop = top)
  #dens_surface####
  TreeKDE <- out
  densityKDE<-TreeKDE$density
  idKDE<-setdiff(TreeKDE$id,TreeKDE$parent)
  levelcluster <- list()
  for(i in idKDE){
    tt <- TreeKDE$DataPoints[[i]]
    levelcluster <- c(levelcluster,list(tt))
  }
  numKDEleaves<-length(idKDE)
  l<-1
  KDEdensitypeaks<-matrix(1,numKDEleaves,2)
  for (i in idKDE){
    clusterkde<-TreeKDE$DataPoints[[i]]
    KDEdensitypeaks[l,]<-XX[clusterkde[which.max(densityKDE[clusterkde])],]
    l<-l+1
  }
  xmin <-min(XX)
  xmax<-max(XX)
  ymin<-min(XX)
  ymax<-max(XX)
  numcell<-nrow(XX)
  if (numcell<=10000)
  {
    numx<-101
    numy<-101
  }
  if(numcell>10000)
  {
    numx<-501
    numy<-501
  }
  Xlim <- c(xmin,xmax);  Ylim <- c(ymin, ymax);  
  by <- (xmax-xmin)/(numx-1)
  Xseq <- seq(Xlim[1], Xlim[2], by = by)
  Yseq <- seq(Ylim[2],Ylim[1], by = -by)
  Grid <- expand.grid(Xseq, Yseq)
  # calculate the density on the grid,and form a density surface
  KDE <- ks::kde(XX, h = h, eval.points = Grid)$estimate
  KDE[which(KDE<0)] <- 0
  r <- raster(nrows=numy, ncols=numx, xmn=xmin, xmx=xmax, ymn=ymin, ymx=ymax,crs="+proj=utm +units=m")
  r[] <- KDE
  T <- transition(r, function(x) mean(x), 8)
  T <- geoCorrection(T)
  C <-KDEdensitypeaks
  D <-KDEdensitypeaks
  # use the costDistance function in the gdistance package to calculate the geodesic distance between any two density peaks of 
  # the mesh surface
  dis<- costDistance(T, C, D)
  gp <- graph.adjacency(dis, mode = "undirected", weighted = TRUE)
  dp_mst <- minimum.spanning.tree(gp)
  # calculate the minimun spanning tree by calling the spantree function in the vegan package using the geodesic distance matrix.
  spanningtree <- spantree(dis)
  spantreeendid<-spanningtree$kid
  spantreeid<-matrix(0,numKDEleaves-1,2)
  spantreeid[,1]<-2:numKDEleaves
  spantreeid[,2]<-spantreeendid
  MSTpath<-list()
  for (i in 1:(numKDEleaves-1)) {
    
    id1<-spantreeid[i,1]
    id2<-spantreeid[i,2]
    startpoint<-KDEdensitypeaks[id1,]
    endpoint<-KDEdensitypeaks[id2,]
    shortestpath<-shortestPath(T,startpoint,endpoint,output='SpatialLines')
    pathpoints<-as.matrix(((((shortestpath@lines)[[1]])@Lines)[[1]])@coords)
    startid<-matrix(id1,nrow=(dim(pathpoints)[1])+2,ncol=1)
    endid<-matrix(id2,nrow=(dim(pathpoints)[1])+2,ncol=1)
    pathpoints<-rbind(startpoint,pathpoints,endpoint)
    newpath<-cbind(pathpoints,startid,endid)
    MSTpath<-c(MSTpath,list(newpath))
    
  }
  
  #globalpoints####
  for (i in 1:length(MSTpath)) {
    temp<-MSTpath[[i]]
    if (i==1)
      globalpoints<-temp
    else
      globalpoints<-rbind(globalpoints,temp)
  }
  #findpath####

  findpath<-function(node,prev_node,info){
    adj<-which(info[node,]!=0)
    kid<-setdiff(adj,prev_node)
    if(length(kid)==0)
      return(list(node))
    t<-list()
    l<-1
    for (i in kid) {
      path <- findpath(i, node, info)
      for (j in 1:length(path)) {
        t[[l]]<-c(node,path[[j]])
        l<-l+1
      }
    }
    return(t)
  }
 
  #waypoints####
  #将每个细胞映射到MST上的点上
  if(missing(originid)){
    originid <- 1
    disroot<-costDistance(T,XX[originid,],KDEdensitypeaks)
    rootid<-which.min(disroot)
    adj<-matrix(0,length(MSTpath)+1,length(MSTpath)+1)
    adj[spantreeid]<-1
    adj<-(adj+t(adj))
    allpath<-findpath(rootid,rootid,info = adj)
    
    waypoints <- matrix(0,nrow = nrow(XX),ncol = 2)
    for (i in 1:nrow(XX)) {
      # print(i)
      point<-XX[i,]
      dis<-costDistance(T,point,globalpoints[,1:2])
      waypoints[i,]<-globalpoints[min(which(dis==min(dis))),1:2]
    }
    bran_assign <- list()
    c <- 1
    fre <- as.integer(table(spantreeid))
    for(i in 1:length(allpath)){
      onepath <- allpath[[i]]
      ttfre <- fre[onepath]
      ttbreak <- which(ttfre>2)
      ttbreak <- c(1, ttbreak, length(onepath))
      for(i in 1:(length(ttbreak)-1)){
        bran_assign[[c]] <- onepath[ttbreak[i]:ttbreak[i+1]]
        c <- c+1
      }
    }
    bran_assign <- unique(bran_assign)
    
    cellpathmap <- matrix(0, nrow = nrow(waypoints), ncol = 4)
    tt <- globalpoints[,1:2]
    for(i in seq_len(nrow(waypoints))){
      tt[,1] <- globalpoints[,1]-waypoints[i,1]
      tt[,2] <- globalpoints[,2]-waypoints[i,2]
      tt1 <- min(which(apply(abs(tt),1,sum)==0))
      tt2 <- which(globalpoints[,3]==globalpoints[tt1,3] & globalpoints[,4]==globalpoints[tt1,4])
      cellpathmap[i,1] <- globalpoints[tt1,3]
      cellpathmap[i,2] <- globalpoints[tt1,4]
      cellpathmap[i,3] <- tt1-min(tt2)+1
      cellpathmap[i,4] <- length(tt2)
    }
    cell_on_bran <- list()
    for(i in 1:length(bran_assign)){
      tt <- bran_assign[[i]]
      ttcell <- integer()
      for(j in (1:length(tt)-1)){
        tt1 <- which(cellpathmap[,1]==tt[j]&cellpathmap[,2]==tt[j+1])
        tt2 <- which(cellpathmap[,2]==tt[j]&cellpathmap[,1]==tt[j+1])
        if(length(tt1)!=0)
          ttcell <- c(ttcell, tt1)
        else
          ttcell <- c(ttcell, tt2)
      }
      cell_on_bran <- c(cell_on_bran, list(ttcell))
    }
    
    out_DP <- list(pseudobran = cell_on_bran)
    
  }else{
    disroot<-costDistance(T,XX[originid,],KDEdensitypeaks)
    rootid<-which.min(disroot)
    adj<-matrix(0,length(MSTpath)+1,length(MSTpath)+1)
    adj[spantreeid]<-1
    adj<-(adj+t(adj))
    allpath<-findpath(rootid,rootid,info = adj)
    point<-XX[originid,]
    dis<-costDistance(T,point,globalpoints[,1:2])
    tt <- globalpoints[min(which(dis==min(dis))),1:2]
    originwaypoint <- matrix(tt, ncol = 2)
    waypoints <- matrix(0,nrow = nrow(XX),ncol = 2)
    pseudotime <- double()
    for (i in 1:nrow(XX)) {
      # print(i)
      point<-XX[i,]
      dis<-costDistance(T,point,globalpoints[,1:2])
      waypoints[i,]<-globalpoints[min(which(dis==min(dis))),1:2]
      pseudotime[i] <- costDistance(T,originwaypoint, waypoints[i,])
    }
    pseudotime <- pseudotime/max(pseudotime)
    bran_assign <- list()
    c <- 1
    fre <- as.integer(table(spantreeid))
    for(i in 1:length(allpath)){
      onepath <- allpath[[i]]
      ttfre <- fre[onepath]
      ttbreak <- which(ttfre>2)
      ttbreak <- c(1, ttbreak, length(onepath))
      for(i in 1:(length(ttbreak)-1)){
        bran_assign[[c]] <- onepath[ttbreak[i]:ttbreak[i+1]]
        c <- c+1
      }
    }
    bran_assign <- unique(bran_assign)
    
    cellpathmap <- matrix(0, nrow = nrow(waypoints), ncol = 4)
    tt <- globalpoints[,1:2]
    for(i in seq_len(nrow(waypoints))){
      tt[,1] <- globalpoints[,1]-waypoints[i,1]
      tt[,2] <- globalpoints[,2]-waypoints[i,2]
      tt1 <- min(which(apply(abs(tt),1,sum)==0))
      tt2 <- which(globalpoints[,3]==globalpoints[tt1,3] & globalpoints[,4]==globalpoints[tt1,4])
      cellpathmap[i,1] <- globalpoints[tt1,3]
      cellpathmap[i,2] <- globalpoints[tt1,4]
      cellpathmap[i,3] <- tt1-min(tt2)+1
      cellpathmap[i,4] <- length(tt2)
    }
    cell_on_bran <- list()
    for(i in 1:length(bran_assign)){
      tt <- bran_assign[[i]]
      ttcell <- integer()
      for(j in (1:length(tt)-1)){
        tt1 <- which(cellpathmap[,1]==tt[j]&cellpathmap[,2]==tt[j+1])
        tt2 <- which(cellpathmap[,2]==tt[j]&cellpathmap[,1]==tt[j+1])
        if(length(tt1)!=0)
          ttcell <- c(ttcell, tt1)
        else
          ttcell <- c(ttcell, tt2)
      }
      cell_on_bran <- c(cell_on_bran, list(ttcell))
    }
    ttallpath <- list()
    for(i in 1:length(allpath)){
      tt1 <- allpath[[i]]
      tt2 <- KDEdensitypeaks[allpath[[i]],]
      ttallpath[[i]] <- list(node = tt1, position = tt2)
    }
     out_DP <- list(RCSs = levelcluster, pseudotime = pseudotime, pseudobran = cell_on_bran, MSTtree = dp_mst, allpath = ttallpath)
     return(out_DP)
  }
 
}


#example for s8791data
## 1.load gene expression data, each row of data represents one cell and each column represents one gene
testdata <- R.matlab::readMat('~/DensityPath/s8971data.mat')
OriginalData <- testdata$s8971data

## 2.use PCA to reduce the dimensionality for OriginalData
data_afterPCA <- after_pca(OriginalData)
write.csv(data_afterPCA,'~/DensityPath/data_afterPCA.csv')

## 3.perform EE in matlab
#     Y=csvread('data_afterPCA.csv',1,1)；     % First, load the data_afterPCA in matlab;
#     run EEcode.m     % Second, ran the the code "EEcode.m" to reduce the dimensionality to 2 for data_afterPCA;
#     save('~/DensityPath/data_EE.mat','X')    % Third, save the variable "X" which the dimensionality is 2 as "data_EE.mat".

## 4.load the data after EE for reconstructing trajectory
data_EE <- R.matlab::readMat('~/DensityPath/data_EE.mat')
XX <- data_EE$X

## 5.Obtain the result of DensityPath
densitypathimage(XX,"s8971")

## 6.Calculate the pseudotime 
dens_bran_pseuXX <- dens_bran_pseu(XX, originid=1)
#display the minmum spanning tree of the high density clusters
plot(dens_bran_pseuXX$MSTtree)





