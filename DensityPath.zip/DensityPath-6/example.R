#example for s8791data
## 1.load gene expression data, each row of data represents one cell and each column represents one gene
testdata <- R.matlab::readMat('~/DensityPath/s8971data.mat')
OriginalData <- testdata$s8971data

## 2.use PCA to reduce the dimensionality for OriginalData
data_afterPCA <- after_pca(OriginalData)
write.csv(data_afterPCA,'~/DensityPath/data_afterPCA.csv')

## 3.perform EE in matlab
# First, load the data_afterPCA in matlab;
# Second, ran the the code to reduce the dimensionality to 2 for data_afterPCA;
# Third, save the variable "X" whose the dimensionality is 2 as "data_EE.mat".

## 4.load the data after EE for reconstructing trajectory
data_EE <- R.matlab::readMat('~/DensityPath/data_EE.mat')
XX <- data_EE$X

## 5.Obtain the result of DensityPath
densitypathimage(XX,"s8971")

## 6.Calculate the pseudotime 
dens_bran_pseuXX <- dens_bran_pseu(XX, originid=1)
#display the minmum spanning tree of the high density clusters
plot(dens_bran_pseuXX$MSTtree)
